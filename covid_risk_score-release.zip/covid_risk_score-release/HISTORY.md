## v0.3.0
---------------------------------
* QA review with Fei and Kelsey
* QA review by Matt Salganik

## v0.2.0
----------------------------------
* Deployed to shinyapps.io


## v0.1.0
-----------------------------------
* Started the project! Woohoo!
* Initial creation of each module
